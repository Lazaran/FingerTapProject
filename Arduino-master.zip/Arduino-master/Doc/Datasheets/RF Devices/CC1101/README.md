## 2018-08-12 Patapom

Amount of chips: 4
Ordered from https://www.elecrow.com/433mhz-rf-transceiver-cc1101-module-p-374.html

Check "Notes on CC1101.txt" file for technical details which are munched down and digested from the large PDF files contained in that folder.

The CC1101 RF chip has been (unsuccessfully) tested in the TestCC1101 project, I wrote a nice library to drive the chip though.
I originally attempted to use these chips to read and remote control my boiler that uses those with its thermostat, but the temperature
 regulation is so badly designed I needed to write my own. But I failed, even at simply *receiving* the simple data I was sending... :/
