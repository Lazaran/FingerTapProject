## 2018-08-12 Patapom

RFD21733   (RFD21735 variant without built-in antenna)

Amount of chips: 2

Ordered from https://www.mouser.fr/new/rfdigital/rfdigital-RFD21733/

Other websites:
* Module:			http://www.rfdigital.com/product/rfd21733-rfdp8-rf-module-4/index.html
* DIP version:	http://www.rfdigital.com/product/rfd21813-dip-version-of-rfd21733/index.html
* USB Dongle:		http://www.rfdigital.com/product/rfd21807-rfdp8-usb-dongle/index.html			<== Interesting to completely bypass the Arduino if needed! Apparently limited to 9600 bauds??
* Eval Board:		http://www.rfdigital.com/product/rfd21737-eval-board-for-rfd21733/index.html


First RF chip I ever checked.
* 2.4GHz
* Apparently very easy to use
* 150 meters range
* UNFORTUNATELY ==> 9600 bauds max!
