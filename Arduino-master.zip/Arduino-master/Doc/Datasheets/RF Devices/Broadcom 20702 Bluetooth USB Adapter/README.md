## 2018-08-12 Patapom

You'll find here the content of the CD provided with the Bluetooth USB Adapter from 

Technically, nothing interesting. Only end-user drivers for the USB device and instructions to install the driver and use the device to connect to other bluetooth devices.
The actual datasheets are not there!

I think the product is https://www.gmyle.com/device/gadgets/usb-bluetooth-dongles/ubbthadpv4

Product Features
* Equipped with Broadcom *BCM20702*. Compatible with Bluetooth specification 4.0 and older versions.
* Support Bluetooth Low Energy Technology.
* Provide data access via USB 2.0 version interface.
* Can work with 7 device at the same time,support maximum asynchronous transfer rate of 3Mbps.
* Support Windows 8.1, Windows 8 and more.

