## 2018-08-12 Patapom

**nRF24L01**
Amount of chips: 10
Ordered from https://www.mouser.fr/new/rfdigital/rfdigital-RFD21733/

Tutorial: https://www.carnetdumaker.net/articles/communiquer-sans-fil-avec-un-module-nrf24l01-la-bibliotheque-mirf-et-une-carte-arduino-genuino/


First RF chip I ever checked.
* 2.4GHz
* Max 2 MBauds!! Great!