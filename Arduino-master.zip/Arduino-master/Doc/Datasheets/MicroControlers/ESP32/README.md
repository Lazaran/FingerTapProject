## 2018-08-12 Patapom

**Espressif ESP32-wroom-32**
Number of pieces: 2

Ordered from e-bay:			
Also available at Amazon:	https://www.amazon.fr/AZ-Delivery-NodeMCU-d%C3%A9veloppement-d%C3%A9nergie-successeur/dp/B071P98VTG/ref=sr_1_2?ie=UTF8&qid=1534095937&sr=8-2&keywords=ESP-WROOM-32

Another micro-controller, better than Arduino according to some friend. Needs to test it some day if Arduino proves itself to be too limited...
https://www.espressif.com/en/products/hardware/esp-wroom-32/overview
