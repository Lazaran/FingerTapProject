## 2018-09-18 Patapom

**MAX9814** Electret Microphone Amplifier - MAX9814 with Auto Gain Control

Number of pieces: 10

Ordered from Amazon:	https://www.amazon.fr/dp/B0713SK1XH/ref=pe_3044141_185740131_TE_item


# Connections


# Project pages

