## 2018-09-18 Patapom

**MCP4725** 12-Bit Digital-to-Analog Converter with EEPROM Memory in SOT-23-6 (Means "Small-Outline-Transistor")

Number of pieces: 10

Ordered from Amazon:	https://www.amazon.fr/dp/B07912SK2X/ref=pe_3044141_189395771_TE_dp_1


# Connections


# Project pages

