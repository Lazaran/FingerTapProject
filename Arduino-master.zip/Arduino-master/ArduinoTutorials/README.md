## 2018-08-13 Patapom

Contains the projects corresponding to Arduino Lessons from the Elegoo Starter Kit "Elegoo The Most Complete Starter Kit for UNO V1.0.17.05.09"
The Elegoo starter kit documents can be found at http://www.elegoo.com/tutorial/


