# Pixel Circle Generator

[![Node.js CI](https://github.com/donatj/Circle-Generator/actions/workflows/ci.yml/badge.svg)](https://github.com/donatj/Circle-Generator/actions/workflows/ci.yml)

Generates Pixel Circles

Web frontend here: [https://donatstudios.com/PixelCircleGenerator](https://donatstudios.com/PixelCircleGenerator)
